<template>
  <div class="login">
    {{ message }}
    <input v-model="username" placeholder="用户名">
    <input v-model="password" placeholder="密码">
    <button v-on:click="login">登陆 </button>
  </div>
</template>
 
<script>
    export default {
      name: "login",
      data() {
        return {
          message: 'Hello Vue!',
          username: '',
          password: ''
        }
      },
      http: {
        headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
      },
      methods: {
        login: function () {
          var _this = this;
        //   console.log(_this.username+_this.password);
          _this.$http.post('http://47.93.60.249:8080/login', {
                username: _this.username,
                password: _this.password
          },{emulateJSON:true}
          )
            .then(function (response) {
              var errorcode = response.data.state;
              console.log(response.data.data)
             console.log(errorcode);
              if (errorcode == "2000") {
                _this.$router.push(
                  { path: '/Success',
                    query: {
                      user: response.data.data,
                    }
                  });
              } else {
                _this.$router.push({ path: '/Fail' });
              }
            })
            .catch(function (error) {
              console.log(error);
            });
        }
      }
 
    }
</script>
 
<style scoped>
 
</style>
