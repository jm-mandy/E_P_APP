<template>
  <div class="hello">
    <h2>{{ msg }}</h2>
  </div>
</template>
 
<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: '登陆成功'
    }
  }
}
</script>

<style scoped>
h1, h2 {
  font-weight: normal;
}

</style>
 