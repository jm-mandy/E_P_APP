<template>
<div class="search-body">
   <form action="" v-on:submit.prevent="">
  <mt-search
  v-model="searchValue"
  cancel-text="取消"
  placeholder="请输入要搜索的内容"
  @keyup.enter.native="search"
  class="my-search"
  style="width:100%;height:auto;"
  >
  </mt-search>
</form>
</div>
</template>
<script>
export default {
    data(){
        return {}
    },
    watch:{
    searchValue:function(newvs,oldvs){
	console.log("newvs",newvs);
        console.log("oldvs",oldvs);
	if(!newvs){
	  this.getList();
	}
    }
},

}
</script>
<style scoped>
.search-body{
    background-color: #fff;
}
.my-search{
     background-color: #a4bd8b;font-size:18px;
}
.mintui .mintui-search{
    font-size:22px;
}
.mint-searchbar{
    border:2px solid #eee;
}
</style>>
