<template>
    <div class="fun-body">
       <div class="xiala">
           <img src="../../../../assets/zhankai1.png" alt="">
       </div>
       <div class="fun-list">
           <div class="img1">
               <img src="../../../../assets/xihuan1.png" alt="">
           </div>
           <div class="img2">
               <img src="" alt="">
           </div>
           <div class="img3">
                <img src="" alt="">
           </div>
           <div class="img4">
                <img src="" alt="">
           </div>
       </div>
    </div>
</template>
<script>
export default {
    data(){
        return {}
    }
}
</script>
<style scoped>
.fun-body{
    height: 368px;
    width:80px;
}
.xiala{
    width:80px;
    height:80px;
    background-color: #6b836b;
}
</style>