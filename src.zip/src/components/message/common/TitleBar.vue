<template>
<mt-navbar v-model="selected">
    <div class="page-head">
       <!-- 顶部的导航条 -->
       <!-- (1)左侧保存一个签到图标 推荐 最新 -->
      
        <div @click="qiandao" class="imgdiv r">
           <img  style="width:25px" :src="leftImg" alt="">
       </div>
       <div class="words" @click="tuijian"><span>推荐</span></div>
       <div class="words" @click="zuixin"><span>最新</span></div>
       
       <div class="right-head">
       <!-- (2)右侧一个搜索和一个添加标志 -->
       <!-- (3)并添加点击事件 -->
        <div @click="search" class="imgdiv r1">
           <img  style="width:25px" :src="rightFirstImg" alt="">
       </div>
       <div @click="add" class="imgdiv r2">
           <img style="width:25px" :src="rightSecondImg" alt="">
       </div>
       </div>
    </div></mt-navbar>
</template>
<script>
export default {
    data(){
        return {
         
        }
    },
    //声明接收父组件传递数据
    props:{
        leftImg:{default:""},
        rightFirstImg:{default:""},
        rightSecondImg:{default:""},
        tuijian:{default:""},
        zuixin:{default:""},
        qiandao:{
            type:Function
        },
        search:{
            type:Function
        },//声明函数:类型检测
        add:{
            type:Function
        }//类型检测
    }
}
</script>
<style scoped>

  /* 1.scoped 防止样式冲突，自动为选择器加一随机数 */
  /* 2.最外层父元素 */
.page-head{
   display: flex;
/* 移动端项目首选布局flex */
 position:fixed;
 z-index: 999;
/* 显示在元素上面 */
 width:100%;
/* 宽度与父元素相同 */
 justify-content: space-between;
/* 子元素两端对齐 */
 align-items: center;
/* 垂直居中 */
 background:linear-gradient( top,#7a8866,#a4bd8b);
 height:4.5625rem;
/* padding-left:0.21875rem;
 padding-right:0.21875rem;
 */
 color:#fff;
 font-size:1.125rem;
}
.r{
     margin-left: 0.625rem;
}
.r1{
     margin-right: 1.75rem;
}
 .r2{
     margin-right:0.625rem;
}
 
  /* 2.文字选中设置 */
  /* .words span{
      font-size:18px;
  } */
  /* 3.右侧 */
  .right-head{
    display: flex;
    position:relative;
    bottom:7px;
    height:28px;
    width:100px;
    padding: 4px;
    margin-left:47px;
  }
  
  /* .right-head img{
      display: block;
      position: relative;
      right:31px;
      top:4px;
      width:20px;
      height:20px;
  } */
.r1{
      margin-right:10px;
  }
  /* 4.搜索图片单独处理 */
  .imgdiv{
      display:flex;
      align-items: center;
      height:48px;
      margin-right:18px;
  }
</style>
