<template>
    <div>
        <mt-popup 
        v-model="popupVisible" position="bottom" popup-transition="popup-fade"></mt-popup>
    </div>
</template>
<script>
export default {
    data(){
        return {}
    }
}
</script>
<style scoped>

</style>