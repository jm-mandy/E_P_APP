import Vue from 'vue'
import Router from 'vue-router'
import Login from "./components/message/Login.vue"
import Success from "./components/message/Success.vue"
import HomeExc from "./components/message/HomeExc.vue"
import Search from "./components/message/common/Search.vue"
import Add from "./components/message/common/Add.vue"
import Fail from "./components/message/Fail.vue"
Vue.use(Router)
// 为Exam01.vue 组件指定访问路径
// 1.在router.js 引入组件


Vue.use(Router)
export default new Router({
  routes: [
   {path:'/Login',component:Login},
    {path:'/HomeExc',component:HomeExc},
    {path:'/Add',component:Add},
    {path:'/Search',component:Search},
    {path:'/Success',component:Success},
    {path:'/Fail',component:Fail}
  ]
})
